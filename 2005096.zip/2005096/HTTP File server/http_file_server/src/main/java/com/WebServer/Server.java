package com.WebServer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.Buffer;
import java.util.Scanner;

public class Server {
    public static int PORT=5096;
    public static void main(String[] args) {

        // Create log directory
        File baseDir=new File("");
        String logPath=baseDir.getAbsolutePath();
        logPath=logPath+"/log";
        File logDir=new File(logPath);
        if(!logDir.exists()){
            logDir.mkdir();
        }
        else{
            String []entries = logDir.list();
            for(String s: entries){
                File currentFile = new File(logDir.getPath(),s);
                currentFile.delete();
            }
        }
        String logDirPath=logDir.getAbsolutePath();


        // Create root directory
        String rootPath=baseDir.getAbsolutePath()+"/root";
        File rootDir=new File(rootPath);
        if(!rootDir.exists()){
            rootDir.mkdir();
        }


        // Create upload directory
        String uploadPath=baseDir.getAbsolutePath()+"/uploaded";
        File uploadDir=new File(uploadPath);
        if(!uploadDir.exists()){
            uploadDir.mkdir();
        }


        // an html page showing the list of all files
        String htmlfile=readFile("index.html");
        // 
        try{
            ServerSocket server = new ServerSocket(PORT,100);
            System.out.println("Server started on port: "+PORT);
            while(true){
                Socket socket = server.accept();
                System.out.println("Client connected: "+socket.getInetAddress());
                // System.out.println(htmlfile);
                ServerThread serverThread = new ServerThread(socket,logDirPath,htmlfile);
                serverThread.start();
            }
        }
        catch(Exception e){
            e.printStackTrace();
    }
}
    public static String readFile(String filename){
        String data="";
        try{
            File file=new File(filename);
            FileInputStream fileInputStream=new FileInputStream(file);
            StringBuilder stringBuilder=new StringBuilder();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(fileInputStream,"UTF-8"));
            String line;
            while((line=bufferedReader.readLine())!=null){
                stringBuilder.append(line);
                stringBuilder.append("\n");
            }
            return stringBuilder.toString();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return data;
}
}

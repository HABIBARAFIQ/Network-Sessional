package com.WebServer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringBufferInputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
public class ServerThread extends Thread {
    private Socket  socket;
    private DataInputStream in;
    private DataOutputStream out;
    private String data;
    private BufferedReader buffreader;
    //private BufferedWriter buffwriter;
    private String logDirPath;
    private String htmlFile;
    private PrintStream printStream;
    private static int req_count=0;
    private static int CHUNK_SIZE=1024*4;
    public ServerThread(Socket socket,String logDirPath,String htmlFile) {
        this.socket = socket;
        this.logDirPath=logDirPath;
        try {
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());
            buffreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //buffwriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            printStream = new PrintStream(socket.getOutputStream());
        } catch (Exception e) {
            e.printStackTrace();
    }
    this.data=data;
    this.htmlFile=htmlFile;
}
    public void run() {
        PrintWriter fileWriter = null;
        try {
            System.out.println("Client in run " );
            String request="";
            try {
                request = buffreader.readLine();
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
            if(request!=null){
                // System.out.println("Request: "+request);
            }
            else {
                System.out.println("Request is null");
                return;
            }

            //"GET /index.html HTTP/1.0"
            String method=request.split(" ")[0];
            //GET
            String fileName=request.split(" ")[1];
            // /index.html
            String []reqPart=request.split(" ");
            //GET, /index.html, HTTP/1.0
            String basePath=new File("").getAbsolutePath();
            String path=basePath+reqPart[1];
            // /home/username/HTTP%20File%20server/http_file_server/root/index.html
            String url=reqPart[1];
            // /index.html
            // System.out.println("URL: "+url);
            fileWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(logDirPath + "\\http_log_" + (++req_count) + ".log"))));
            fileWriter.println("HTTP REQUEST LINE FROM CLIENT:\n"+"\n");
            fileWriter.println("HTTP RESPONSE TO CLIENT:");
            // System.out.println("FileWriter :"+fileWriter);
            if(method.equalsIgnoreCase("UPLOAD"))
            {
                receivedFile(fileName);
            }

            else if(url.equals("/")){
                // System.out.println("Hi");
                // System.out.println("HTML Template Before Replacement:\n" + htmlFile);
                String HtmlPage=htmlFile.replace("<content>","<h1>Welcome</h1>Click to visit File Server<a class=\"btn btn-primary\" href=\"root/\">Click</a>");
                String HtmlHeader=buildHeader("/",HtmlPage.length(),"text/html","200 OK");
                printStream.println(HtmlHeader);
                printStream.println(HtmlPage);
                // System.out.println("HTML Header:\n" + HtmlHeader);  
                fileWriter.write(HtmlHeader);
                // System.out.println("FileWriter :"+fileWriter);
            }
            else if(url.startsWith("/root")){
                File file=new File(path);
                if(!file.exists()){
                    String HtmlPage=htmlFile.replace("<content>","<h1>Error 404</h1><h2>File Not Found</h2>");
                    String HtmlHeader=buildHeader("/",HtmlPage.length(),"text/html","404 Not Found");
                    printStream.println(HtmlHeader);
                    printStream.println(HtmlPage);
                    fileWriter.write(HtmlHeader);
                    // System.out.println("FileWriter :"+fileWriter);
                }
                else if(file.isDirectory())
                {   String HtmlPage=buildDirectory(path,url);
                    HtmlPage=htmlFile.replace("<content>",HtmlPage);
                    String HtmlHeader=buildHeader("/",HtmlPage.length(),"text/html","200 OK");
                    printStream.println(HtmlHeader);
                    printStream.println(HtmlPage);
                    fileWriter.write(HtmlHeader);
                    // System.out.println("FileWriter :"+fileWriter);
                }
                else{
                    String resposnse = sendFile(path);
                    fileWriter.write(resposnse);
                    // System.out.println("FileWriter :"+fileWriter);
                }
            }
            else{
                    String HtmlPage=htmlFile.replace("<content>","<h1>Error 404</h1><h2>File Not Found</h2>");
                    String HtmlHeader=buildHeader("/",HtmlPage.length(),"text/html","404 Not Found");
                    printStream.println(HtmlHeader);
                    printStream.println(HtmlPage);
                    fileWriter.write(HtmlHeader); 
                    // System.out.println("FileWriter :"+fileWriter);
            }
            // out.writeUTF("Message received: " + requestLine);
            // out.flush();
            fileWriter.flush();
            out.close();
            printStream.close();
            buffreader.close();
            //buffwriter.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void receivedFile(String fileName) {
        
        try {
            BufferedWriter buffwriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            buffwriter.write("Start");
            buffwriter.newLine();
            buffwriter.flush();

            int Bytes=0;
            byte []buffer=new byte[CHUNK_SIZE];

            String basePath=new File("").getAbsolutePath();
            String path=basePath+"/uploaded/"+fileName;
            FileOutputStream fileOutputStream=new FileOutputStream(path);

            long fileSize=0;
            while((Bytes=in.read(buffer))>0){
                fileOutputStream.write(buffer,0,Bytes);
                fileSize+=Bytes;
            }
            fileOutputStream.close();
            buffwriter.close();
            in.close();
            System.out.println("File Uploaded: "+fileName);
        
        }
        catch(Exception e){
            e.printStackTrace();
    }
}
    private String sendFile(String path) throws Exception{
        StringBuilder stringBuilder=new StringBuilder();
        File file=new File(path);
        int Bytes=0;
        FileInputStream fileInputStream=new FileInputStream(file);
        String mimeType=URLConnection.guessContentTypeFromName(file.getName());
        if(mimeType==null){
            mimeType="application/octet-stream";
        }
        out.writeBytes("HTTP/1.0 200 OK\r\n");
        out.writeBytes("Server: Java HTTP Server: 1.0\r\n");
        out.writeBytes("Date: " + new Date() + "\r\n");
        out.writeBytes("Content-Type: "+mimeType+"\r\n");
        stringBuilder.append("HTTP/1.0 200 OK\r\n");
        stringBuilder.append("Server: Java HTTP Server: 1.0\r\n");
        stringBuilder.append("Date: " + new Date() + "\r\n");
        stringBuilder.append("Content-Type: "+mimeType+"\r\n");
        System.out.println("MIME Type: "+mimeType);

        if(mimeType.startsWith("text/")|| mimeType.startsWith("image/")){
            stringBuilder.append("Content-Disposition: inline; filename="+file.getName()+"\r\n");
            out.writeBytes("Content-Disposition: inline; filename="+file.getName()+"\r\n");
        }
        else{
            stringBuilder.append("Content-Disposition: attachment; filename="+file.getName()+"\r\n");
            out.writeBytes("Content-Disposition: attachment; filename="+file.getName()+"\r\n");
        }
        out.writeBytes("Content-Length: "+file.length()+"\r\n");
        stringBuilder.append("Content-Length: "+file.length()+"\r\n");
        out.writeBytes("\r\n");
        out.flush();
        byte []buffer=new byte[CHUNK_SIZE];
        while((Bytes=fileInputStream.read(buffer))!=-1){
            out.write(buffer,0,Bytes);
            out.flush();
        }
        fileInputStream.close();
        return stringBuilder.toString();
        
    }
    private String buildDirectory(String path, String url) {
        StringBuilder stringBuilder=new StringBuilder();
        if(!url.equals("/root/"))
        {
            stringBuilder.append("<a class=\"btn btn-primary\" href=\"../\">Back</a>");
        }
        stringBuilder.append("<table class=\"table table-striped\">");
        stringBuilder.append("<tr>");
        stringBuilder.append("<th>File Name </th>");
        stringBuilder.append("<th>File Size </th>");
        stringBuilder.append("<th>File Type </th>");
        stringBuilder.append("<th>Action</th>");
        stringBuilder.append("</tr>");
        File file=new File(path);

        String []files=file.list();
        for(String s:files){
            File currentFile = new File(path+"/"+s);
            stringBuilder.append("<tr>");
            stringBuilder.append("<td><a href=" +url+"/"+ s + ">" + s + "</a></td>");
            stringBuilder.append("<td>"+currentFile.length()+"</td>");
            if(currentFile.isDirectory()){
                stringBuilder.append("<td>Directory</td>");
            }
            else{
                stringBuilder.append("<td>File</td>");
            }
            stringBuilder.append("<td><a class=\"btn btn-primary\" href=" +url+"/"+ s + ">" +(currentFile.isDirectory()? "Open" : "")+"</a></td>");
            stringBuilder.append("</tr>");
        }
        stringBuilder.append("</table>");
        return stringBuilder.toString();
       
    }
    private String buildHeader(String string, long length, String string2, String string3) {

        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append("HTTP/1.0 200 OK\r\n");
        stringBuilder.append("Server: Java HTTP Server: 1.0\r\n");
        stringBuilder.append("Date: "+new Date()+"\r\n");
        stringBuilder.append("Content-type: "+string2+"\r\n");
        stringBuilder.append("Content-length: "+length+"\r\n");
        return stringBuilder.toString();
    }

}

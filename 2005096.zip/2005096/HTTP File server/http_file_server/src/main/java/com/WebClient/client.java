package com.WebClient;

import java.util.Scanner;

public class client {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(true){
            String dataPath = scanner.nextLine();
            clientThread clientThread = new clientThread(dataPath);
            clientThread.start();
        }
    }
}

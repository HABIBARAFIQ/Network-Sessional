package com.WebClient;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.nio.Buffer;

import javax.xml.crypto.Data;

public class clientThread extends Thread {
    public static final int PORT=5096; 
    public static final String HOST="127.0.0.1";
    private String dataPath;
    private Socket socket;
    private int CHUNK_SIZE=1024*4;
    public clientThread(String dataPath) {
        this.dataPath = dataPath;
    }
    public void run() {
        try{
            File file = new File(dataPath);
            if(!file.exists()){
                System.out.println("File does not exist");
                return;
            }
            System.out.println("Client thread started");
            socket = new Socket(HOST,PORT);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            BufferedReader buffreader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter buffwriter= new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            FileInputStream fileInputStream = new FileInputStream(file);
            System.out.println("Connected to server");
            String fileName=file.getName();
            buffwriter.write("Upload "+fileName);
            buffwriter.newLine();
            buffwriter.flush();
            String response=buffreader.readLine();

            byte [] buffer = new byte[CHUNK_SIZE];
            int bytesRead=0;
            while((bytesRead=fileInputStream.read(buffer))>0){
                out.write(buffer,0,bytesRead);
                out.flush();
            }
            System.out.println("File sent to server");

            out.close();
            buffreader.close();
            buffwriter.close();
            fileInputStream.close();
            socket.close();
        }
        catch(Exception e){
            e.printStackTrace();
        
    }

}
}
